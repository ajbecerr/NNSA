#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec  5 13:57:10 2024

@author: ggeorg01
"""

import os
import pandas as pd
import re



# Load the parameters from CSV
parameters = pd.read_csv("./../ablate_parameters_MMA.csv")

# Base files and folder paths
base_yaml_file = "./Base/2dSlabRadNoabs.yaml"
output_dir = "./"

# Create output directories
os.makedirs(output_dir, exist_ok=True)

# Function to update the YAML file
def update_yaml_as_text(file_path, params, folder_id):
    # Read the YAML file as plain text
    with open(file_path, "r") as file:
        content = file.read()
    
    # Update the title field
    content = content.replace(
        "title: _slabBurner2DZerork",
        f"title: _slabBurner2DZerork_{folder_id}"
    )

    # Update surfaceGrowthPreExpnential
    if "surfaceGrowthPreExpnential" in content:
        content = re.sub(
            r"surfaceGrowthPreExpnential:\s*[\d.]+",
            f"surfaceGrowthPreExpnential: {params['surfaceGrowthPreExpnential']}",
            content
        )
	
    # Update latentHeatOfFusion
    if "latentHeatOfFusion" in content:
        content = re.sub(
            r"latentHeatOfFusion:\s*[\d.]+",
            f"latentHeatOfFusion: {params['lv']}",
            content
        )
        
    # Update surfaceGrowthPreExpnential
    if "nucleationPreExponential" in content:
         content = re.sub(
             r"nucleationPreExponential:\s*[\d.]+",
             f"nucleationPreExponential: {params['nucleationPreExponential']}",
             content
        )
    
    # Update velFac
    if "velFac" in content:
        content = re.sub(
            r"velFac:\s*[\d.]+",
            f"velFac: {params['velFac']}",
            content
        )
        
    #update absorptivity
    if "absorptivity" in content:
        content = re.sub(
            r"absorptivity:\s*[\d.]+",
            f"absorptivity: {params['absorptivity']}",
            content
        )
    
    # Write the updated content back to the file
    return content


# Main loop
for idx in range(64):
    folder_id = idx + 1
    folder_path = os.path.join(output_dir, str(folder_id))
    os.makedirs(folder_path, exist_ok=True)

    # Get parameter row for this folder
    param_row = parameters.iloc[idx]

    # Update and save YAML file
    updated_content = update_yaml_as_text(base_yaml_file, param_row, folder_id)
    with open(os.path.join(folder_path, "2dSlabRadNoabs.yaml"), "w") as yaml_file:
        yaml_file.write(updated_content)
